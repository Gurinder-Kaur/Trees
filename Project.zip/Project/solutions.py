class T_Node:
    def __init__(self, value):
        self.value = value
        self.left = None
        self.right = None

class BST:
    def __init__(self, root):
        self.root = T_Node(root)
        self.nodes_num = 1
        self.nodes = [self.root]

    def insert(self, new_val):
        self.insertHelp(self.root, new_val)
        self.nodes_num = self.nodes_num+1

    def insertHelp(self, ptr, new_val):
        if ptr.value < new_val:
            if ptr.right:
                self.insertHelp(ptr.right, new_val)
            else:
                ptr.right = T_Node(new_val)
                self.nodes.append(ptr.right)
        else:
            if ptr.left:
                self.insertHelp(ptr.left, new_val)
            else:
                ptr.left = T_Node(new_val)
                self.nodes.append(ptr.left)

    def get_adjacency_matrix(self):
        max_index = self.nodes_num
        adj_matrix = [[0 for i in range(max_index)] for j in range(max_index)]
        for node in self.nodes:
            if node.left:
                adj_matrix[node.value][node.left.value] = 1
            if node.right:
                adj_matrix[node.value][node.right.value] = 1
        return adj_matrix

class Element():
    def __init__(self, value):
        self.value = value
        self.next = None

class LinkedList():
    def __init__(self, head=None):
        self.head = Element(head)

    def append(self, new_element):
        current = self.head
        if self.head:
            while current.next:
                current = current.next
            current.next = Element(new_element)
        else:
            self.head = Element(new_element)

    def total_elements(self):
        current = self.head
        i = 1
        while current.next:
                i = i+1
                current = current.next
        return i

class Node:
    def __init__(self, value):
        self.value = value
        self.edges = []

class Edge:
    def __init__(self, value, node_from, node_to):
        self.value = value
        self.node_from = node_from
        self.node_to = node_to

class Graph:
    def __init__(self, nodes = None, edges = None):
        self.nodes = nodes or []
        self.edges = edges or []
        self.node_names = []
        self._node_map = {}

    def set_node_names(self, names):
        self.node_names = list(names)

    def insert_node(self, new_node_val):
        new_node = Node(new_node_val)
        self.nodes.append(new_node)
        self._node_map[new_node_val] = new_node
        return new_node

    def insert_edge(self, new_edge_val, node_from_val, node_to_val):
        nodes={node_from_val : None, node_to_val : None}
        for node in self.nodes:
            if node.value in nodes:
                nodes[node.value] = node
                if all(nodes.values()):
                    break
        for node_val in nodes:
            nodes[node_val] = nodes[node_val] or self.insert_node(node_val)
        node_from = nodes[node_from_val]
        node_to = nodes[node_to_val]
        new_edge = Edge(new_edge_val, node_from, node_to)
        node_from.edges.append(new_edge)
        node_to.edges.append(new_edge)
        self.edges.append(new_edge)

    def get_adjacency_list(self):
        max_index = self.find_max_index()
        adj_list = [[] for i in range(max_index)]
        for e in self.edges:
            adj_list[e.node_from.value].append((e.node_to.value,e.value))
        return [a or None for a in adj_list]

    def get_adjacency_list_names(self):
        adj_list = self.get_adjacency_list()
        def convert_to_names(pair, graph=self):
            node_number,value = pair
            return (graph.node_names[node_number],value)
        def map_conversion(adjacency_list_for_node):
            if adjacency_list_for_node is None:
                return None
            return list(map(convert_to_names, adjacency_list_for_node))
        return [map_conversion(adjacency_list_for_node)
                for adjacency_list_for_node in adj_list]

    def find_max_index(self):
        if len(self.node_names) > 0:
            return len(self.node_names)
        max_index = -1
        if len(self.nodes):
            for node in self.nodes:
                if node.value > max_index:
                    max_index = node.value
        return max_index

    def get_parameter(self):
        para={}
        adj_list = self.get_adjacency_list_names()
        for index,node in enumerate(self.node_names):
            para[node] = adj_list[index]
        return para

#function to determine whether some anagram of t is a substring of s
def question1(s,t):       #s and t are strings
    s_list = list(s)       #list is made out of first string
    for j in t:
        if j in s_list:
            s_list.remove(j)      #once the element from s_list is matched ,it is removed so that it can't be proessed again
        else:
            return False
    return True

#find the longest palindromic substring
def question2(s):
    n = len(s)
    lis = []
    max = 2     #taken 2 because single letter is not considerd as pallindrome here
    pallindrome = None
    for i in range(n):
        for j in range(i+1,n+1):
            if helper_pallindrome(s[i:j]):
                lis.append(s[i:j])            #list of all pallindromic substrings
    for item in lis:
        if len(item) > max:
            pallindrome = item                 #to store the longest substring
            max = len(item)
    return pallindrome

#helper function to determine whether string is pallindrome or not
def helper_pallindrome(s):
    st = ""
    for i in s:
        st = i + st
    if st == s:
        return True
    else:
        return False

#minimum spanning tree
def question3(G):
    Ver = [i for i in G]           #stored all nodes of graph in list
    mst = Graph()
    vert_num = get_num(Ver)         #assigned numbers to nodes, i.e, A:0, B:1 and so on
    weight_matrics = [[0]*len(vert_num) for _ in range(len(vert_num))]   #metrix to store edge_weights where indices represent nodes
    for i in G:
        for j in G[i]:
            if(vert_num[i] < vert_num[j[0]]):               #only elements above the daigonal is taken otherwise one edge was considered twice
                weight_matrics[vert_num[i]][vert_num[j[0]]] = j[1]

    sortedWeights = sorted_edgeWeights(weight_matrics) #to get the list of (weight,node_1,node_2)
    mst.set_node_names((i for i in vert_num))
    parent = [-1]*len(vert_num)                         #list of parents of nodes

    for i in sortedWeights:
            x = find_parent(parent,i[1])                #get parents of nodes, same parents implies cycle in the Graph
            y = find_parent(parent,i[2])
            if x != y:                                     #ignore edge that makes cycle
                mst.insert_edge(i[0],i[1],i[2])
                mst.insert_edge(i[0],i[2],i[1])
                union(parent,x,y)                           #makes one the parent of other --used for detecting cycles
            if all(Ver) in mst.nodes:                       #once all the nodes are processed, then STOP
                break

    return mst.get_parameter()

#helper function to assign numbers to nodes
def get_num(L):
    num = {}
    i = 0
    for item in L:
        num[item] = i
        i = i+1
    return num

#helper function to get (weight,node_1,node_2) in in increasing order of edge weight values
def sorted_edgeWeights(M):
    wei = []
    for i in M:
        for j in i:
            if j != 0:
                wei.append([j,M.index(i),i.index(j)])
    return sorted(wei, key=lambda x: x[0])

def find_parent(parent, i):
    if parent[i] == -1:
        return i
    if parent[i] != -1:
        return find_parent(parent, parent[i])

#hepler function to make one node the parent of another node where both nodes belong to single edge
def union(parent,x,y):
    x_set = find_parent(parent, x)
    y_set = find_parent(parent, y)
    parent[x_set] = y_set

#least common ancestor
def question4(T, r, n1, n2):
    path1 = find_path(T, n1)            #get the path of both nodes
    path2 = find_path(T, n2)
    lca = helper_LCA(path1, path2)        #compare the path, first common node is least common ancestor
    return lca

#function to find path from node to root
def find_path(matrix, node):
    path = [node]
    i = 0
    ele = get_parent(matrix, node)    #to get the parent of node
    while ele:
        path.append(ele)                #insert parent unless reached root
        i = i+1
        ele =get_parent(matrix, path[i])
    return path[1:]                   #ignoring the node itself in path

#function to get parent of node
def get_parent(M, N):
    list = []
    for item in M:
        list.append(item[N])       #list of nth column as 1(row-index) of nth column give its parent
    if 1 in list:
        return list.index(1)
    else:
        return None

#fuction to get first common element of two list
def helper_LCA(p1, p2):
    for item in p1:
        if item in p2:
            return item
    return None

#function to get last mth element of linked list
def question5(L, m):
    total = L.total_elements()   #get total elemnts in LL
    num = total-m                 #total-m gives position from starting
    if(num < 0 or m<=0):                   # if m is more than total elements return None
        return None
    current = L.head
    for i in range(num):              #iterate for num times to get output
        current=current.next
    return current.value


print("solution1:")
print(question1('udacity','ca'))
      #returns True as "ca" is anagram of "udacity"
print(question1('datt','dtaa'))
      #returns False ,no doubt letters are same dut the frequency of 'a' in 'dtaa' is more
print(question1('data','sa'))
      #returns False as 's' is not available in 'data'
print(question1('data',''))
      #returns True for empty string

print("\nsolution2:")
print (question2('wahegurugewaha'))
       #returns eguruge as it is the longest pallindromic substring
print (question2('lollozzo'))
       #both 'ollo' and 'ozzo' are of same length
       #returns 'ollo' as it occured First
print (question2('udacity'))
       #returns None as single letter is not considered as longest pallindromic substring in the function



print("\nsolution3:")
grp1 = Graph()
grp1.set_node_names(('A','B','C','D','E'))
grp1.insert_edge(2,0,2)
grp1.insert_edge(2,2,0)
grp1.insert_edge(7,1,0)
grp1.insert_edge(7,0,1)
grp1.insert_edge(10,1,4)
grp1.insert_edge(10,4,1)
grp1.insert_edge(3,1,3)
grp1.insert_edge(3,3,1)
grp1.insert_edge(3,2,4)
grp1.insert_edge(3,4,2)
grp1.insert_edge(2,3,2)
grp1.insert_edge(2,2,3)
G1=grp1.get_parameter()
print("Minimum spanning Tree 1")
print(question3(G1))
     #input given:
     #{'A': [('C', 2), ('B', 7)], 'B': [('A', 7), ('E', 10), ('D', 3)], 'C': [('A', 2), ('E', 3), ('D', 2)],
     #'D': [('B', 3), ('C', 2)], 'E': [('B', 10), ('C', 3)]}
     #output:
     #{'A': [('C', 2)], 'B': [('D', 3)], 'C': [('A', 2), ('D', 2), ('E', 3)],
     #'D': [('C', 2), ('B', 3)], 'E': [('C', 3)]}
grp2 = Graph()
grp2.set_node_names(('A','B','C'))
grp2.insert_edge(12,0,2)
grp2.insert_edge(12,2,0)
grp2.insert_edge(17,1,0)
grp2.insert_edge(17,0,1)
grp2.insert_edge(7,1,2)
grp2.insert_edge(7,2,1)
G2=grp2.get_parameter()
print("Minimum spanning Tree 2")
print(question3(G2))
      #input given:
      #{'A': [('C', 12), ('B', 17)], 'B': [('A', 17), ('C', 7)], 'C': [('A', 12), ('B', 7)]}
      #output:
      #{'A': [('C', 12)], 'B': [('C', 7)], 'C': [('B', 7), ('A', 12)]}

print("\nsolution4:")
tree = BST(4)
tree.insert(2)
tree.insert(1)
tree.insert(3)
tree.insert(0)
tree.insert(5)
Tree=tree.get_adjacency_matrix()
      #Tree:[[0, 0, 0, 0, 0, 0],
            #[1, 0, 0, 0, 0, 0],
            #[0, 1, 0, 1, 0, 0],
            #[0, 0, 0, 0, 0, 0],
            #[0, 0, 1, 0, 0, 1],
            #[0, 0, 0, 0, 0, 0]]
print(question4(Tree,4,0,5))
       #returns 4(root) as 0 and 5 belongs to left and right subtrees respectively
print(question4(Tree,4,0,4))
       #returns None as 4(root) has no ancestor
print(question4(Tree,4,0,1))
       #returns 2
print(question4(Tree,4,0,3))
       #returns 2

print("\nsolution5:")
ll = LinkedList(1)
ll.append(2)
ll.append(3)
ll.append(4)
ll.append(5)
ll.append(6)
      #ll: 1->2->3->4->5->6
print(question5(ll,6))
      #returns 1 as its 6th element from last
print(question5(ll,1))
      #returns 6 as its 1th element from last
print(question5(ll,3))
      #returns 4
print(question5(ll,7))
      #returns None as it exceeds the total num in LL
